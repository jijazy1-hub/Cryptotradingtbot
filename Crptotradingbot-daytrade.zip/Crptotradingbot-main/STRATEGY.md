# How honest is the strategy? (v2.3.0)

This bot now measures its own BUY signals instead of claiming a "confidence %".

## What gets tested

The backtester (`src/services/strategyBacktest.js`) replays history through **the exact function the live scanner uses** (`evaluateSignal` in `src/services/scanEngine.js`). It uses the same candle windows (260 × 4H, 100 × 1H, 50 × 15M), and only candles that had closed at the time.

Each BUY is traded exactly the way the Telegram alert tells you to:

| Step | Rule |
|---|---|
| Entry | Next 15M candle's **open**, plus slippage (you can't buy at the close that created the signal) |
| Stop | The alert's stop price (1.5 × 1H ATR below the signal price) |
| TP1 (1.5R) | Sell 40% → move stop to breakeven |
| TP2 (2.5R) | Sell 35% → move stop to TP1 |
| TP3 (4R) | Sell the remaining 25% |
| Same candle hits stop and target | Counted as a **loss** (conservative) |
| Price gaps below the stop | Filled at the gap price, not the stop |
| Costs | 0.1% fee on every buy and sell (Binance spot taker) + 0.05% slippage on market fills |
| Sizing | 1% of the account risked per trade, no leverage, one position per coin |

All of these can be changed from the command line (see below).

## How to read the results

- **Avg per trade (R)** is the most important number. R is the amount you risk on a trade (entry minus stop). **+0.20R** means risking $10 per trade earned $2 per trade on average. **Below 0, the strategy lost money.** Below +0.05R is called "roughly breakeven", because the edge is too small to rely on.
- **Win rate** comes with a **95% range**. 12 wins out of 20 is "60%", but the honest range is about 39–78%. With fewer than **30 trades**, results are flagged as too few to trust.
- **Profit factor** is total winnings ÷ total losses, after fees. Above 1 is profitable.
- **Max drawdown** is the worst fall from a peak in account value.
- **Buy & hold** is what simply holding the coin did over the same period. If the strategy can't beat it, ask why you're trading.
- **By setup score** shows whether higher scores actually did better. If they didn't, the score isn't adding information.

A full stop costs more than −1R once fees and slippage are included (around −1.2R with the defaults). The stops are tight (1.5 × 1H ATR), so costs are a big share of the risk.

## Where the numbers appear

- **Every BUY alert in Telegram** carries a line like: *Backtest Apr–Oct 2026, all signals, fees incl.: 64 trades · 47% win (likely 35–59%) · avg +0.12R per trade*. If the strategy lost money in testing, the alert says so.
- **Dashboard → Track Record tab** shows the full tables.
- **`/api/backtest`** returns the raw JSON.

The old "Confidence 73%" bar (score ÷ 15) is gone. The setup score (x/15) is still shown, labelled as what it is: how many conditions lined up, not a probability.

## Running it

Run it from a computer that can reach Binance; Kraken alone has too little history.

```bash
npm run backtest                                      # BINANCE_SYMBOLS, last 180 days
npm run backtest -- --days 365                        # longer history = more trades = more trustworthy
npm run backtest -- --symbols SOLUSDT,ETHUSDT
npm run backtest -- --fee 0.075 --slippage 0.1        # BNB fee discount, more slippage
npm run backtest -- --max-hold-hours 72               # add a time stop
```

Then **commit and push `data/strategy-stats.json`** so the deployed bot shows the numbers. Re-run monthly; markets change.

## Research result (October 2026)

`npm run research` tested 48 variants on 12 coins over 365 days:
- decision on 15m or 1h closes;
- stops of 1.5×, 2.5× or 3.5× the 1H ATR;
- no filter, a coin-trend filter, a BTC-trend filter, or both;
- 4h or 24h between entries.

It chose a variant on the first 8 months and judged it once on the last 4.

- Every variant lost money on the first 8 months (best: −0.088R per trade).
- On the unseen months, the original lost −0.113R per trade (95% range −0.20 to −0.03R).
- The chosen variant (3.5× stop, 24h gap) made +0.028R, but its 95% range was −0.15 to +0.20R: indistinguishable from zero.
- **Verdict: no reliable edge. BUY alerts should stay off.**

To re-run: `npm run research` (add `-- --days 540` for more history). If a future variant passes, the tool prints the settings for `src/config/strategy.js`, the one file that controls the live scanner and the backtest.

## What is still NOT tested

- **Moonshot / scan / listings scores (0–92).** They depend on CoinGecko and KuCoin snapshots that have no free history, so they can't be backtested here. Every message now labels them as a heuristic score, not a probability.
- **Exits from `check` / `v2advice` advice** (e.g. "close partial when MACD fades"). The backtest follows the alert's fixed plan only.
- **Past performance does not predict future results.** A positive backtest is necessary, not sufficient.

## Day trading (v2.23.0)

`npm run daylab` tests **one-day** strategies on **every Binance USDT coin** (stablecoins, fiat, gold, wrapped and leveraged tokens excluded). The practice day trader (`daytrade on`) runs the strategy it picks, using the same code (`src/strategies/day.js`).

| Step | Rule |
|---|---|
| Which coins | Every Binance USDT coin listed 30+ days with a 7-day average volume of at least $5M, judged with data up to the signal day only |
| Pick | At the daily close (00:00 UTC), the top N coins by the strategy's rule |
| Entry | Next day's open + slippage |
| Exit | That day's close (the next 00:00 UTC) — or the stop, a fixed % below the entry |
| Costs | 0.1% fee per buy and per sell + 0.05% slippage |
| Train / test | Settings chosen on the older 65% of the history, judged once on the newer 35% |

Families tested (each with top 3 / top 5, a 3% / 6% stop, with / without the BTC 100-day filter — 24 variants):
- **Yesterday's biggest risers** (≥ +3%) — momentum continuation
- **Bounce after a big drop** (≤ −5%) — short-term reversal
- **New 20-day high on big volume**

Same verdict rules as above (PASS needs 30+ unseen trades, > +0.05R, profit factor > 1.2 and a 95% range above zero).

**Read the results with care:**
- One-day trades pay the round-trip cost (~0.3%) every single day, so the edge has to be large. Short-term crypto strategies usually fail this test; a FAIL is a real answer, not a bug.
- **Survivorship bias:** the coin list is today's Binance list. Coins that were delisted — often after crashing — are missing, which flatters the results (the "bounce" family most).
- Live, the bot buys a few minutes after the open and sells a few minutes after the close (the 10-minute quickcheck runs it), so fills differ slightly from the test.
- It is **practice (play money) only**. Real-money day trading is not built; it would need a PASS here and a profitable forward test first. The bot's own day-trade account (`dayhouse`) is that forward test, shown in `daytrade`.

Without `data/day-strategy.json` the bot runs a fallback (yesterday's top 3 risers, 6% stop, BTC filter) labelled **NOT TESTED** everywhere.
