const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os');
const path = require('path');
const { mockNet, resetEnv } = require('./helpers');

const DAY = 86_400_000;

/**
 * Daily candles ending yesterday (the last CLOSED candle): a gentle uptrend,
 * then a final day that moves `lastMove` (e.g. 0.12 = +12%).
 * `usdVolume` = dollar volume per day.
 */
function series(limit, { lastMove = 0, usdVolume = 10_000_000, start = 100, growth = 0.002 } = {}) {
  const end = Math.floor(Date.now() / DAY) * DAY;
  const out = [];
  let prev = start;
  for (let i = 0; i < limit; i++) {
    const close = i === limit - 1 ? prev * (1 + lastMove) : start * (1 + growth) ** i;
    out.push({ time: end - (limit - i) * DAY, open: prev, high: Math.max(prev, close) * 1.002, low: Math.min(prev, close) * 0.998, close, volume: usdVolume / close });
    prev = close;
  }
  return out;
}

// The coins on our fake Binance, and how each moved yesterday
const COINS = {
  BTCUSDT: { lastMove: 0.01 },
  AAAUSDT: { lastMove: 0.15 },  // biggest riser
  BBBUSDT: { lastMove: 0.10 },
  CCCUSDT: { lastMove: 0.06 },
  DDDUSDT: { lastMove: 0.04 },  // 4th — not in a top 3
  EEEUSDT: { lastMove: 0.30, usdVolume: 50_000 },   // huge move but illiquid → never picked
  FFFUSDT: { lastMove: 0.40, newListing: true },     // brand-new listing → never picked
  GGGUSDT: { lastMove: -0.08 },
  USDCUSDT: { lastMove: 0.0 },  // stablecoin → excluded
};

function setup() {
  resetEnv({ DAY_STRATEGY_FILE: path.join(os.tmpdir(), 'no-such-day-strategy.json') });
  const net = mockNet({
    price: 100,
    klines: (sym, interval, limit) => {
      const c = COINS[sym] || {};
      if (interval !== '1d') return series(limit, c).map((x, i) => ({ ...x, time: Date.now() - (limit - i) * 60_000 }));
      return series(c.newListing ? Math.min(limit, 10) : limit, c);
    },
    extra: (method, url) => {
      if (url.endsWith('/exchangeInfo')) return { data: { symbols: Object.keys(COINS).map(s => ({ symbol: s, baseAsset: s.replace('USDT', ''), quoteAsset: 'USDT', status: 'TRADING', isSpotTradingAllowed: true })) } };
      if (url.endsWith('/ticker/24hr')) return { data: Object.entries(COINS).map(([s, c]) => ({ symbol: s, quoteVolume: String(c.usdVolume ?? 10_000_000) })) };
      return undefined;
    },
  });
  return { net, dt: require('../src/services/dayTrader'), practice: require('../src/services/practiceService') };
}

const strategy = (family, params) => ({ family, params, id: `${family}:test`, label: 'test', tested: false });

test('day strategies: picks yesterday\'s top risers among liquid coins; skips thin coins, new listings and stablecoins', async () => {
  const { dt } = setup();
  const sig = await dt.computeSignals(strategy('dayMomentum', { topN: 3, stopPct: 0.06, regime: true }));
  assert.deepEqual(sig.buys.map(b => b.symbol), ['AAAUSDT', 'BBBUSDT', 'CCCUSDT']);
  assert.match(sig.buys[0].why, /rose \+15\.0% yesterday/);
  assert.equal(sig.regimeUp, true);
  assert.equal(sig.listed, 8, 'starts from every Binance USDT coin (minus stablecoins), not a fixed list');
  assert.equal(sig.scanned, 6, 'the thin coin and the 10-day-old listing are dropped before scoring');

  const dip = await dt.computeSignals(strategy('dayDip', { topN: 3, stopPct: 0.06, regime: false }));
  assert.deepEqual(dip.buys.map(b => b.symbol), ['GGGUSDT'], 'only coins that fell 5%+');
});

test('day-trade lab: one-day trades, fees charged, stops fill at the stop', () => {
  const { dayTrade } = require('../src/services/dayLab');
  const { prepare } = require('../src/strategies');
  const c = series(40);
  const ind = Object.assign(prepare(c), { symbol: 'AAAUSDT' });
  const i = c.length - 2;
  // Next day falls 10% → the 6% stop is hit
  ind.c[i + 1] = { ...ind.c[i + 1], open: 100, high: 101, low: 90, close: 92 };
  const stopped = dayTrade(ind, i, 0.06);
  assert.equal(stopped.reason, 'stop');
  assert.ok(stopped.r < -1 && stopped.r > -1.1, 'a full stop is a bit worse than −1R once fees are paid');
  // Next day rises → sold at that day's close
  ind.c[i + 1] = { ...ind.c[i + 1], open: 100, high: 105, low: 99, close: 104 };
  const won = dayTrade(ind, i, 0.06);
  assert.equal(won.reason, 'close');
  assert.ok(won.pnlPct > 3.5 && won.pnlPct < 4, '+4% minus fees and slippage');
  assert.equal(won.exitTime - won.entryTime, DAY - 1, 'held for exactly one day');
});

test('day-trade lab: research runs on many coins and judges on unseen data only', () => {
  const { dayResearch } = require('../src/services/dayLab');
  const data = { BTCUSDT: series(400, { growth: 0.001 }) };
  for (let k = 0; k < 12; k++) {
    let s = k + 1; const rnd = () => (s = (s * 16807) % 2147483647) / 2147483647;
    const end = Math.floor(Date.now() / DAY) * DAY;
    let px = 50 + k;
    data[`C${k}USDT`] = Array.from({ length: 400 }, (_, i) => {
      const open = px; px = px * (1 + (rnd() - 0.5) * 0.12);
      return { time: end - (400 - i) * DAY, open, high: Math.max(open, px) * 1.01, low: Math.min(open, px) * 0.99, close: px, volume: 10_000_000 / px };
    });
  }
  const out = dayResearch(data);
  assert.equal(out.families.length, 3);
  assert.ok(['PASS', 'PROMISING', 'FAIL'].includes(out.verdict));
  assert.ok(out.universe.avgEligiblePerDay >= 10);
  const f = out.families.find(x => x.chosen);
  assert.ok(f.test.trades > 0 && f.test.avgDays === 1, 'every trade lasts one day');
  assert.ok(out.period.split > out.period.from && out.period.split < out.period.to);
});

test('daily run: sells yesterday\'s day trades, then buys today\'s for the forward test and users who switched it on', async () => {
  const { net, dt, practice } = setup();
  await dt.setOn('2000', true);
  const allowed = new Set(['1000', '2000', '3000']);
  const send = async (id, text) => net.sent.push({ chat_id: id, text });
  const today = new Date(Math.floor(Date.now() / DAY) * DAY + 5 * 60_000);

  const r = await dt.runDaily({ allowed, send, now: today });
  assert.equal(r.signals, 3);
  assert.equal(dt.currentStrategy().verdict, 'NOT TESTED', 'without the lab file the fallback is clearly labelled');
  const mine = (await practice.summary('2000')).positions;
  assert.deepEqual(mine.map(p => p.coin).sort(), ['AAA', 'BBB', 'CCC']);
  assert.ok(mine.every(p => p.day && !p.auto), 'day trades are not managed by the auto-buy trailing stop');
  assert.ok(mine.every(p => p.stopLossPrice < p.buyPrice * 0.95 && p.stopLossPrice > p.buyPrice * 0.93), 'stop about 6% below the entry');
  assert.ok(mine.every(p => p.cost <= 2000.01), 'no coin above 20% of the account');
  assert.equal((await practice.summary(dt.HOUSE)).positions.length, 3, 'the day-trade forward test buys too');
  assert.ok(net.sent.some(m => m.chat_id === '2000' && /Day trades for today/.test(m.text)));
  assert.ok(!net.sent.some(m => m.chat_id === '3000'), 'users who did not switch it on get nothing');
  assert.ok(net.sent.some(m => m.chat_id === '1000' && /Day-trade check/.test(m.text)), 'admin gets a report');
  assert.equal((await dt.runDaily({ allowed, send, now: today })).skipped, 'already ran today');

  // Next day: yesterday's trades are sold at the daily close, new ones bought
  net.sent.length = 0;
  const r2 = await dt.runDaily({ allowed, send, now: new Date(today.getTime() + DAY) });
  assert.equal(r2.closed, 6, '3 for the user + 3 for the forward test');
  const trades = await practice.getTrades('2000');
  assert.equal(trades.length, 3);
  assert.ok(trades.every(t => t.exits.includes('dayclose')));
  assert.ok(net.sent.some(m => m.chat_id === '2000' && /Day trades closed at the daily close/.test(m.text)));
  assert.equal((await practice.summary('2000')).positions.length, 3, 'today\'s new day trades');
});

test('switching off stops new buys but the open day trades are still sold at the close', async () => {
  const { dt, practice } = setup();
  await dt.setOn('2000', true);
  const allowed = new Set(['2000']);
  const today = new Date(Math.floor(Date.now() / DAY) * DAY + 5 * 60_000);
  await dt.runDaily({ allowed, now: today });
  await dt.setOn('2000', false);
  await dt.runDaily({ allowed, now: new Date(today.getTime() + DAY) });
  assert.equal((await practice.summary('2000')).positions.length, 0);
  assert.equal((await practice.getTrades('2000')).length, 3);
});

test('market filter: no day trades while BTC is below its 100-day average', async () => {
  const { dt } = setup();
  COINS.BTCUSDT.lastMove = -0.5;
  try {
    const sig = await dt.computeSignals(strategy('dayMomentum', { topN: 3, stopPct: 0.06, regime: true }));
    assert.equal(sig.regimeUp, false);
    assert.equal(sig.buys.length, 0);
    assert.match(dt.noBuyMessage(sig, strategy('dayMomentum', { topN: 3, stopPct: 0.06, regime: true })), /below its 100-day average/);
  } finally { COINS.BTCUSDT.lastMove = 0.01; }
});

test('admin pause stops day trading', async () => {
  const { dt } = setup();
  await dt.pause(true);
  assert.equal((await dt.runDaily({ force: true })).skipped, 'paused by admin');
});
