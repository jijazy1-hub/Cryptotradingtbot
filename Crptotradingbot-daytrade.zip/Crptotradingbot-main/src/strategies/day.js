/**
 * ─── Day-trade strategies (one-day trades, every liquid Binance coin) ────────
 * Shared by the day-trade lab (src/services/dayLab.js) and the practice day
 * trader (src/services/dayTrader.js), so what is tested is exactly what runs.
 *
 * Every strategy works the same way:
 *  - At the daily close (00:00 UTC = 1am Lagos) it looks at EVERY Binance USDT
 *    coin that is liquid enough and picks the top N by its rule.
 *  - It buys them at the next day's open and sells them at that day's close
 *    (the next 00:00 UTC). Nothing is held overnight past one daily candle.
 *  - A stop a fixed % below the entry protects each trade during the day.
 *
 *   dayMomentum  yesterday's biggest risers (≥ +3%) — "what went up keeps going"
 *   dayDip       yesterday's biggest drops (≤ −5%) — "a sharp drop bounces"
 *   dayBreakout  closed above its 20-day high, ranked by how unusual the volume was
 *
 * Optional market filter on all: only trade while BTC closes above its 100-day
 * average (the same filter the auto-buy strategy uses).
 */

const { priorHigh } = require('./index');

const DAY_MS = 86_400_000;

/** Coins must have this much history and trading volume to be considered. */
const ELIGIBILITY = {
  minHistoryDays: 30,      // skip brand-new listings (their first weeks are erratic)
  volumeDays: 7,           // average daily volume over this many days…
  minVolumeUsd: 5_000_000, // …must be at least this many dollars
};

/** Dollar volume of a daily candle (Binance gives it; otherwise close × volume). */
const quoteVol = (c) => (Number.isFinite(c.quoteVolume) && c.quoteVolume > 0 ? c.quoteVolume : c.close * c.volume);

function avgQuoteVol(c, i, n) {
  if (i - n + 1 < 0) return null;
  let s = 0;
  for (let j = i - n + 1; j <= i; j++) s += quoteVol(c[j]);
  return s / n;
}

/** Is this coin tradable for a day strategy at index i (data up to and incl. i only)? */
function eligible(ind, i, rules = ELIGIBILITY) {
  if (i < rules.minHistoryDays) return false;
  const v = avgQuoteVol(ind.c, i, rules.volumeDays);
  return v !== null && v >= rules.minVolumeUsd;
}

const $ = (p) => (p >= 1 ? `$${Number(p).toLocaleString('en-US', { maximumFractionDigits: p >= 1000 ? 0 : 4 })}` : `$${Number(p).toPrecision(4)}`);
const pct = (x) => `${x >= 0 ? '+' : '−'}${Math.abs(x * 100).toFixed(1)}%`;

const DAY_STRATEGIES = {
  dayMomentum: {
    name: 'Yesterday\'s biggest risers',
    describe: (p) => `buy the ${p.topN} liquid Binance coins that rose most yesterday (at least +3%), sell at the day's close; stop −${p.stopPct * 100}%`,
    /** Score for ranking (higher = better), or null if the coin doesn't qualify. */
    score(ind, i) {
      const r = ind.close[i] / ind.close[i - 1] - 1;
      return r >= 0.03 ? r : null;
    },
    why(ind, i) {
      const r = ind.close[i] / ind.close[i - 1] - 1;
      return `rose ${pct(r)} yesterday to ${$(ind.close[i])} — one of the biggest risers on Binance`;
    },
  },
  dayDip: {
    name: 'Bounce after a big drop',
    describe: (p) => `buy the ${p.topN} liquid Binance coins that fell most yesterday (at least −5%), sell at the day's close; stop −${p.stopPct * 100}%`,
    score(ind, i) {
      const r = ind.close[i] / ind.close[i - 1] - 1;
      return r <= -0.05 ? -r : null;
    },
    why(ind, i) {
      const r = ind.close[i] / ind.close[i - 1] - 1;
      return `fell ${pct(r)} yesterday to ${$(ind.close[i])} — one of the biggest drops; the strategy bets on a bounce today`;
    },
  },
  dayBreakout: {
    name: 'New 20-day high on big volume',
    describe: (p) => `buy the ${p.topN} liquid Binance coins that closed above their 20-day high with the most unusual volume, sell at the day's close; stop −${p.stopPct * 100}%`,
    score(ind, i) {
      const h = priorHigh(ind.c, i, 20);
      if (h === null || !(ind.close[i] > h)) return null;
      const base = (() => { let s = 0; for (let j = i - 20; j < i; j++) s += quoteVol(ind.c[j]); return s / 20; })();
      return base > 0 ? quoteVol(ind.c[i]) / base : null;
    },
    why(ind, i) {
      const h = priorHigh(ind.c, i, 20);
      const surge = this.score(ind, i);
      return `closed at ${$(ind.close[i])}, above its 20-day high of ${$(h)}, on ${surge ? surge.toFixed(1) : '?'}× its usual volume`;
    },
  },
};

const GRID = [
  { topN: 3, stopPct: 0.03 }, { topN: 3, stopPct: 0.06 },
  { topN: 5, stopPct: 0.03 }, { topN: 5, stopPct: 0.06 },
];

/** Every variant: each family × grid × with / without the BTC market filter. */
function dayVariants() {
  const out = [];
  for (const [family, s] of Object.entries(DAY_STRATEGIES)) {
    for (const g of GRID) {
      for (const regime of [true, false]) {
        const params = { ...g, regime };
        out.push({ family, params, id: dayId(family, params), label: dayLabel(family, params) });
      }
    }
  }
  return out;
}
const dayId = (family, p) => `${family}:${p.topN}-${Math.round(p.stopPct * 100)}${p.regime ? ':btc' : ''}`;
const dayLabel = (family, p) => `${DAY_STRATEGIES[family].name} — ${DAY_STRATEGIES[family].describe(p)}${p.regime ? ', only while BTC is above its 100-day average' : ''}`;

/**
 * Every qualifying coin for a family on the day that closed at `time`, best first.
 * @param prepared { SYMBOL: prepared indicators (src/strategies prepare) }
 * @returns [{ symbol, i, score }]
 */
function rankedCandidates(family, prepared, time, rules = ELIGIBILITY) {
  const s = DAY_STRATEGIES[family];
  const out = [];
  for (const ind of Object.values(prepared)) {
    const i = ind.timeIndex.get(time);
    if (i === undefined || i < 1 || !eligible(ind, i, rules)) continue;
    const sc = s.score(ind, i);
    if (sc !== null && Number.isFinite(sc)) out.push({ symbol: ind.symbol, i, score: sc });
  }
  return out.sort((a, b) => b.score - a.score || (a.symbol < b.symbol ? -1 : 1));
}

/**
 * Today's picks for one variant. `ranked` can be passed in (the lab reuses one
 * ranking for every variant of a family).
 */
function picksFor(variant, prepared, ctx, time, ranked = null) {
  if (variant.params.regime && !ctx.btcUp(time)) return [];
  return (ranked || rankedCandidates(variant.family, prepared, time)).slice(0, variant.params.topN);
}

module.exports = { DAY_STRATEGIES, ELIGIBILITY, GRID, DAY_MS, dayVariants, dayId, dayLabel, rankedCandidates, picksFor, eligible, quoteVol };
