/**
 * Day-trade settings: one-day trades on every liquid Binance USDT coin.
 * Practice (play money) only — real-money day trading is not built.
 */
module.exports = {
  // Safety limits on every account
  LIMITS: {
    riskPct: 1,          // % of the account lost if a trade hits its stop
    maxPositionPct: 20,  // no single coin bigger than this % of the account
    maxOpen: 5,          // at most this many day trades at once
    minOrderUsd: 5,      // Binance's Spot minimum
  },
  // Used only if data/day-strategy.json (the saved `npm run daylab` result) is
  // missing. Shown as NOT TESTED everywhere until the lab has run.
  FALLBACK: { family: 'dayMomentum', params: { topN: 3, stopPct: 0.06, regime: true } },
  STRATEGY_FILE: 'data/day-strategy.json',
  RUN_AFTER_UTC_MINUTES: 1, // sell yesterday's trades and buy today's from 00:01 UTC (1:01am Lagos)
  // Live: how many of the most-traded coins are fetched each day (Vercel's 60s limit).
  // Coins below roughly half the liquidity rule are never eligible, so they're skipped up front.
  MAX_COINS: 250,
  PREFILTER_VOLUME_USD: 2_500_000,
  // Not coins to trade: stablecoins, fiat, gold and wrapped tokens
  EXCLUDE: new Set([
    'USDC', 'FDUSD', 'TUSD', 'USDP', 'DAI', 'BUSD', 'USDS', 'USDE', 'USD1', 'RLUSD', 'BFUSD', 'XUSD', 'PYUSD', 'USTC',
    'EUR', 'EURI', 'AEUR', 'GBP', 'TRY', 'BRL', 'PAXG', 'XAUT', 'WBTC', 'WBETH', 'BETH', 'BNSOL',
  ]),
  /** Leveraged tokens (BTCUP, ETHDOWN, …) aren't coins either. */
  isTradableBase(base) {
    return !!base && !this.EXCLUDE.has(base) && !/(UP|DOWN|BULL|BEAR)$/.test(base);
  },
};
