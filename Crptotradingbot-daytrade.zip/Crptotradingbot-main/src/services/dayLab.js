/**
 * ─── Day-trade lab: honest tests for the one-day strategies ──────────────────
 * Rules of the test (the same rules the practice day trader follows):
 *  - Coins are picked from CLOSED daily candles only, using only data up to that
 *    close (liquidity, history and the signal itself).
 *  - Each pick is bought at the next day's open and sold at that day's close.
 *  - A stop triggers if the day's low touches it and fills at the stop.
 *  - Every buy and sell pays the 0.1% Binance fee plus 0.05% slippage.
 *  - Train / test: each family's settings are CHOSEN on the older part of the
 *    history and JUDGED only on the newer part they never saw.
 *  - Same verdict rules as the auto-buy lab (src/services/strategyLab.js).
 *
 * Known bias: the coin list is today's Binance list, so coins that were delisted
 * (often after crashing) are missing from the history. That flatters strategies
 * that buy weak coins (dayDip) most. Treat a PASS as necessary, not sufficient.
 */

const { prepare, makeContext } = require('../strategies');
const D = require('../strategies/day');
const { stats, verdictOf, portfolio, FEE, SLIP } = require('./strategyLab');

const round = (x, d = 3) => (Number.isFinite(x) ? Math.round(x * 10 ** d) / 10 ** d : null);

/** One one-day trade: signal at bar i's close → buy bar i+1's open, sell its close (or the stop). */
function dayTrade(ind, i, stopPct) {
  const sig = ind.c[i], b = ind.c[i + 1];
  if (!b || b.time !== sig.time + D.DAY_MS) return null; // a missing day (maintenance, delisting)
  const entry = b.open * (1 + SLIP);
  const stop = entry * (1 - stopPct);
  let exit, reason;
  if (b.low <= stop) { exit = Math.min(stop, b.open) * (1 - SLIP); reason = 'stop'; }
  else { exit = b.close * (1 - SLIP); reason = 'close'; }
  const entryCost = entry * (1 + FEE), exitNet = exit * (1 - FEE);
  return {
    symbol: ind.symbol, entryTime: b.time, exitTime: b.time + D.DAY_MS - 1, entry, exit,
    riskPct: stopPct, r: (exitNet - entryCost) / (entry * stopPct), pnlPct: (exitNet / entryCost - 1) * 100, reason, bars: 1,
  };
}

/**
 * Full research run.
 * @param candlesBySymbol { SYMBOL: [daily candles] } — must include BTCUSDT
 * @param opts.trainFrac share of the timeline used to choose settings (default 0.65)
 * @param opts.rules     coin eligibility (default src/strategies/day ELIGIBILITY)
 */
function dayResearch(candlesBySymbol, { trainFrac = 0.65, rules = D.ELIGIBILITY } = {}) {
  const prepared = {};
  for (const [sym, c] of Object.entries(candlesBySymbol)) {
    if (!c || c.length < rules.minHistoryDays + 2) continue;
    prepared[sym] = Object.assign(prepare(c), { symbol: sym });
  }
  const btc = prepared.BTCUSDT;
  if (!btc || btc.c.length < 120) throw new Error('BTCUSDT daily candles are required (120+ days)');
  const ctx = makeContext(prepared, btc);
  const times = btc.c.map(x => x.time);
  const t0 = times[0], t1 = times[times.length - 1];
  const split = t0 + (t1 - t0) * trainFrac;
  const maxTop = Math.max(...D.GRID.map(g => g.topN));

  // How many coins could be traded each day (shown in the report)
  let eligibleSum = 0, eligibleDays = 0;
  for (let k = 0; k < times.length - 1; k += 7) {
    let n = 0;
    for (const ind of Object.values(prepared)) { const i = ind.timeIndex.get(times[k]); if (i !== undefined && D.eligible(ind, i, rules)) n++; }
    eligibleSum += n; eligibleDays++;
  }

  const all = [];
  for (const family of Object.keys(D.DAY_STRATEGIES)) {
    // Rank once per day per family; every variant of the family reuses it
    const ranked = times.slice(0, -1).map(t => D.rankedCandidates(family, prepared, t, rules).slice(0, maxTop));
    for (const v of D.dayVariants().filter(x => x.family === family)) {
      const train = [], test = [];
      times.slice(0, -1).forEach((t, k) => {
        for (const pick of D.picksFor(v, prepared, ctx, t, ranked[k])) {
          const tr = dayTrade(prepared[pick.symbol], pick.i, v.params.stopPct);
          if (tr) (t < split ? train : test).push(tr);
        }
      });
      all.push({ ...v, trainTrades: train, testTrades: test, train: stats(train), test: stats(test) });
    }
  }

  const testDays = times.filter(t => t >= split).length;
  const families = Object.keys(D.DAY_STRATEGIES).map(family => {
    const cands = all.filter(v => v.family === family && v.train.trades >= 30);
    const best = cands.sort((a, b) => b.train.expectancyR - a.train.expectancyR)[0];
    if (!best) return { family, name: D.DAY_STRATEGIES[family].name, chosen: null, verdict: 'FAIL', why: 'too few trades in the training period' };
    const v = verdictOf(best.test);
    const st = best.testTrades;
    return {
      family, name: D.DAY_STRATEGIES[family].name, chosen: { id: best.id, params: best.params, label: best.label },
      train: best.train, test: { ...best.test, stopRatePct: st.length ? round(st.filter(t => t.reason === 'stop').length / st.length * 100, 1) : null, tradesPerMonth: round(st.length / (testDays / 30.4), 1) },
      portfolioTest: portfolio(st, { maxOpen: 5 }), ...v,
    };
  });

  const ranked = families.filter(f => f.chosen).sort((a, b) => b.train.expectancyR - a.train.expectancyR);
  const pick = ranked[0] || null;
  const iSplit = btc.c.findIndex(x => x.time >= split);
  const btcHold = iSplit >= 0 ? round((btc.close[btc.close.length - 1] / btc.c[iSplit].open - 1) * 100, 1) : null;

  return {
    generatedAt: new Date().toISOString(),
    kind: 'daytrade',
    rules: {
      feePct: FEE * 100, slippagePct: SLIP * 100, entry: 'next daily open', exit: 'same day\'s close (00:00 UTC), or the stop', trainFrac, eligibility: rules,
      bias: 'coin list is today\'s Binance list — delisted coins are missing (survivorship bias)',
    },
    universe: { coins: Object.keys(prepared).length, avgEligiblePerDay: eligibleDays ? Math.round(eligibleSum / eligibleDays) : 0 },
    period: { from: new Date(t0).toISOString().slice(0, 10), split: new Date(split).toISOString().slice(0, 10), to: new Date(t1).toISOString().slice(0, 10) },
    btcBuyHoldTestPct: btcHold,
    families,
    pick: pick ? { family: pick.family, name: pick.name, ...pick.chosen, verdict: pick.verdict, why: pick.why, test: pick.test, train: pick.train, portfolioTest: pick.portfolioTest } : null,
    verdict: pick ? pick.verdict : 'FAIL',
    variants: all.map(v => ({ id: v.id, family: v.family, train: v.train, test: v.test })),
  };
}

module.exports = { dayTrade, dayResearch };
