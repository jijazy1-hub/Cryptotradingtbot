/**
 * ─── Day trader (practice / play money) ──────────────────────────────────────
 * Once a day, just after the daily close (00:01 UTC = 1:01am Lagos, from the
 * 10-minute quickcheck):
 *   1. SELL every day trade bought the day before — at the live price, so each
 *      trade lasts one day. (Stops during the day are handled every 10 minutes
 *      by practiceService.syncUser, like every practice position.)
 *   2. Look at EVERY liquid Binance USDT coin and pick today's coins with the
 *      strategy chosen by `npm run daylab` (data/day-strategy.json).
 *   3. BUY them for the day-trade forward-test account ("dayhouse") and every
 *      user who switched it on (`daytrade on`) — play money only.
 *
 * Same rules as the lab: buy near the daily open, sell near the daily close,
 * stop a fixed % below the entry, 1% of the account at risk per trade, at most
 * 5 day trades at once, no coin above 20% of the account.
 */

const fs = require('fs');
const path = require('path');
const store = require('../lib/redis');
const { fetchKlines, fetchPrice, binanceGet } = require('../lib/market');
const { mapLimit } = require('../lib/concurrency');
const { prepare, makeContext, fmtUsd } = require('../strategies');
const D = require('../strategies/day');
const cfg = require('../config/daytrade');
const practice = require('./practiceService');

const HOUSE = 'dayhouse';
const MAX_TRIES = 6;
const K = {
  users: 'cryptobot:daytrade:users',
  flags: 'cryptobot:daytrade:flags',
  last: 'cryptobot:daytrade:last',
  day: (d) => `cryptobot:daytrade:day:${d}`,
  tries: (d) => `cryptobot:daytrade:tries:${d}`,
  did: (d, id) => `cryptobot:daytrade:did:${d}:${id}`,
  running: 'cryptobot:lock:daytrade',
};

class DayTradeError extends Error {}
const r2 = (x) => Math.round(x * 100) / 100;
const coinOf = (sym) => sym.replace(/USDT$/, '');
const usd = (n) => `${n < 0 ? '-' : ''}$${Math.abs(Number(n)).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const signed = (n) => `${n >= 0 ? '+' : '-'}$${Math.abs(n).toFixed(2)}`;
const fmtP = (p) => (p >= 1 ? Number(p).toFixed(4) : Number(p).toPrecision(4));
const startOfDayUtc = (now) => Math.floor(now.getTime() / D.DAY_MS) * D.DAY_MS;

// ─── Strategy in use ──────────────────────────────────────────────────────────
function loadResearch() {
  const file = process.env.DAY_STRATEGY_FILE || path.join(__dirname, '..', '..', cfg.STRATEGY_FILE);
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
}

function currentStrategy() {
  const res = loadResearch();
  const pick = res?.pick;
  if (pick && D.DAY_STRATEGIES[pick.family]) {
    return { family: pick.family, params: pick.params, id: pick.id, label: pick.label, name: pick.name, verdict: res.verdict, why: pick.why, test: pick.test, portfolioTest: pick.portfolioTest, period: res.period, tested: true };
  }
  const f = cfg.FALLBACK;
  return {
    ...f, id: D.dayId(f.family, f.params), name: D.DAY_STRATEGIES[f.family].name, label: D.dayLabel(f.family, f.params),
    verdict: 'NOT TESTED', why: 'the day-trade lab hasn\'t been run yet — run `npm run daylab` and commit data/day-strategy.json', tested: false,
  };
}

// ─── Coins: every liquid Binance USDT coin ───────────────────────────────────
async function liveUniverse() {
  const [info, tick] = await Promise.all([binanceGet('/exchangeInfo'), binanceGet('/ticker/24hr')]);
  const tradable = new Set((info.data?.symbols || [])
    .filter(s => s.quoteAsset === 'USDT' && s.status === 'TRADING' && s.isSpotTradingAllowed !== false && cfg.isTradableBase(s.baseAsset))
    .map(s => s.symbol));
  const rows = (Array.isArray(tick.data) ? tick.data : [])
    .filter(t => tradable.has(t.symbol) && (parseFloat(t.quoteVolume) || 0) >= cfg.PREFILTER_VOLUME_USD)
    .sort((a, b) => parseFloat(b.quoteVolume) - parseFloat(a.quoteVolume))
    .slice(0, cfg.MAX_COINS);
  return { symbols: rows.map(t => t.symbol), listed: tradable.size };
}

/**
 * Today's picks.
 * @param opts.symbols  coins to look at (default: every liquid Binance USDT coin)
 */
async function computeSignals(strategy, { symbols = null } = {}) {
  const uni = symbols ? { symbols, listed: symbols.length } : await liveUniverse();
  if (!uni.symbols.length) throw new DayTradeError('no Binance coins available — skipped');
  const prepared = {};
  const btcCandles = await fetchKlines('BTCUSDT', '1d', 150, { closedOnly: true, exchange: 'binance' }).catch(() => []);
  if (btcCandles.length < 120) throw new DayTradeError('no BTC daily data — skipped');
  prepared.BTCUSDT = Object.assign(prepare(btcCandles), { symbol: 'BTCUSDT' });
  await mapLimit(uni.symbols.filter(s => s !== 'BTCUSDT'), 10, async (s) => {
    try {
      const c = await fetchKlines(s, '1d', 60, { closedOnly: true, exchange: 'binance' });
      if (c.length >= D.ELIGIBILITY.minHistoryDays + 2) prepared[s] = Object.assign(prepare(c), { symbol: s });
    } catch { /* coin skipped today */ }
  });
  const btc = prepared.BTCUSDT;
  const time = btc.c[btc.c.length - 1].time;
  const ctx = makeContext(prepared, btc);
  const regimeUp = ctx.btcUp(time);
  const b = ctx.btcAt(time) || (() => { const i = btc.c.length - 1; return { close: btc.close[i], sma100: btc.sma100[i] }; })();
  const regimeText = b?.sma100 ? `BTC ${fmtUsd(b.close)} is ${regimeUp ? 'above' : 'below'} its 100-day average ${fmtUsd(b.sma100)}` : 'BTC\'s 100-day average isn\'t available';

  const variant = { family: strategy.family, params: strategy.params };
  // BTC itself is only tradable if it's in today's coin list (it always is in practice)
  const tradable = uni.symbols.includes('BTCUSDT') ? prepared : Object.fromEntries(Object.entries(prepared).filter(([k]) => k !== 'BTCUSDT'));
  const ranked = D.rankedCandidates(strategy.family, tradable, time);
  const eligibleCount = Object.values(tradable).filter(ind => { const i = ind.timeIndex.get(time); return i !== undefined && D.eligible(ind, i); }).length;
  const picks = D.picksFor(variant, tradable, ctx, time, ranked);
  const s = D.DAY_STRATEGIES[strategy.family];
  const buys = picks.map(p => {
    const ind = prepared[p.symbol];
    let why = null;
    try { why = s.why(ind, p.i); } catch { /* wording only */ }
    return { symbol: p.symbol, close: ind.close[p.i], why };
  });
  return {
    date: new Date(time).toISOString().slice(0, 10), buys, regimeUp, regimeText, regimeOn: !!strategy.params.regime,
    scanned: Object.keys(tradable).length, eligible: eligibleCount, qualified: ranked.length, listed: uni.listed,
  };
}

// ─── Sizing ───────────────────────────────────────────────────────────────────
function size({ equity, cash, stopPct, open }) {
  const L = cfg.LIMITS;
  if (open >= L.maxOpen) return { skip: `already ${open} day trades open (max ${L.maxOpen})` };
  const riskUsd = equity * (L.riskPct / 100);
  const wanted = riskUsd / stopPct;
  const amount = Math.min(wanted, equity * (L.maxPositionPct / 100), cash * 0.98);
  if (amount < L.minOrderUsd) return { skip: 'not enough cash for the minimum order' };
  return { usd: r2(amount), riskUsd: r2(amount * stopPct) };
}

// ─── Flags / settings ─────────────────────────────────────────────────────────
const flags = async () => store.hashToObject(await store.cmd('HGETALL', K.flags));
const isPaused = async () => (await flags()).paused === '1';
async function pause(on) { await store.cmd('HSET', K.flags, 'paused', on ? '1' : '0'); }

async function setOn(chatId, on) {
  await store.cmd(on ? 'SADD' : 'SREM', K.users, String(chatId));
  if (on) await practice.getAccount(chatId);
  return on;
}
const isOn = async (chatId) => !!(await store.cmd('SISMEMBER', K.users, String(chatId)));

// ─── Step 1: sell yesterday's day trades ─────────────────────────────────────
async function closeDayTrades(chatId, now) {
  const cutoff = startOfDayUtc(now);
  const old = (await practice.getPositions(chatId)).filter(p => p.day && new Date(p.openedAt).getTime() < cutoff);
  const trades = [];
  for (const p of old) {
    try {
      const r = await practice.sellNow(chatId, { positionId: p.id, reason: 'dayclose' });
      trades.push(...r.trades.filter(Boolean));
    } catch (err) { console.error('[DayTrade] close', chatId, p.id, err.message); }
  }
  return trades;
}

function closedMessage(trades) {
  const total = trades.reduce((s, t) => s + (t.pnlDollar || 0), 0);
  return [
    `📆 PRACTICE · *Day trades closed at the daily close*`,
    ...trades.map(t => `• *${coinOf(t.symbol)}*: ${signed(t.pnlDollar)} (${t.pnlPct >= 0 ? '+' : ''}${t.pnlPct}%)`),
    `*Total:* ${signed(total)} after fees (play money)`,
  ].join('\n');
}

// ─── Step 3: buy today's coins ───────────────────────────────────────────────
async function buyForAccount(chatId, strategy, sig) {
  const out = { bought: [], skipped: [] };
  if (!sig.buys.length) return out;
  const s = await practice.summary(chatId);
  let open = s.positions.filter(p => p.day).length;
  let cash = s.cash;
  const stopPct = strategy.params.stopPct;
  for (const b of sig.buys) {
    const z = size({ equity: s.equity, cash, stopPct, open });
    if (z.skip) { out.skipped.push(`${coinOf(b.symbol)}: ${z.skip}`); if (/max/.test(z.skip)) break; continue; }
    try {
      const live = await fetchPrice(b.symbol, { exchange: 'binance' });
      if (!live) { out.skipped.push(`${coinOf(b.symbol)}: no Binance price right now`); continue; }
      const stop = live * (1 + practice.SLIP) * (1 - stopPct);
      const { position, cash: left } = await practice.buy(chatId, { symbol: b.symbol, amount: z.usd, stop, strategy, why: b.why, day: true });
      cash = left; open++;
      out.bought.push({ coin: coinOf(b.symbol), price: position.buyPrice, qty: position.quantity, usd: z.usd, stop: position.stopLossPrice, why: b.why });
    } catch (err) { out.skipped.push(`${coinOf(b.symbol)}: ${err.message}`); }
  }
  return out;
}

function testLine(strategy) {
  const t = strategy.test;
  if (!strategy.tested || !t) return `_Strategy test: ⚪ not tested yet — the results are an experiment._`;
  return `_Strategy test: ${strategy.verdict} — on ${t.trades} past day trades it never saw, ${t.expectancyR >= 0 ? '+' : ''}${Number(t.expectancyR).toFixed(2)}× the risk per trade after fees._`;
}

function boughtMessage(res, strategy) {
  return [
    `📆 PRACTICE · 🤖 *Day trades for today* (play money)`,
    ``,
    ...res.bought.flatMap(b => [
      `*${b.coin}* — ${+Number(b.qty).toFixed(8)} at ~$${fmtP(b.price)} (${usd(b.usd)}) · stop $${fmtP(b.stop)} (−${r2(strategy.params.stopPct * 100)}%)`,
      b.why ? `   _Why: ${b.why}_` : '',
    ]).filter(Boolean),
    res.skipped.length ? `\nSkipped: ${res.skipped.join(' · ')}` : '',
    ``,
    `*How it sells:* every one of these is sold at the daily close (just after 1am Lagos time), or earlier if it falls to its stop.`,
    testLine(strategy),
  ].filter(x => x !== '').join('\n');
}

function noBuyMessage(sig, strategy) {
  const why = sig.regimeOn && !sig.regimeUp
    ? `${sig.regimeText}. This strategy only trades while BTC is above it.`
    : `none of the ${sig.eligible} liquid Binance coins qualified (${D.DAY_STRATEGIES[strategy.family].describe(strategy.params).split(',')[0]}).`;
  return [`📆 *Day-trade check — ${sig.date}*`, ``, `No day trade today.`, `*Why:* ${why}`, ``, `_Next check: tomorrow just after 1am Lagos time._`].join('\n');
}

// ─── The daily run ────────────────────────────────────────────────────────────
/**
 * @param opts.allowed  Set of chatIds with access (approved / paying)
 * @param opts.send     (chatId, text) => Promise
 * @param opts.force    run even if today's run already happened (admin `daytrade run`)
 */
async function runDaily({ allowed = new Set(), send = async () => {}, force = false, now = new Date() } = {}) {
  if (await isPaused()) return { skipped: 'paused by admin' };
  const mins = now.getUTCHours() * 60 + now.getUTCMinutes();
  if (!force && mins < cfg.RUN_AFTER_UTC_MINUTES) return { skipped: 'waiting for the daily close' };
  const date = now.toISOString().slice(0, 10);
  const admin = process.env.TELEGRAM_CHAT_ID ? String(process.env.TELEGRAM_CHAT_ID) : null;

  if (!force) {
    if (await store.cmd('GET', K.day(date))) return { skipped: 'already ran today' };
    if (!(await store.lock(K.running, 300).catch(() => true))) return { skipped: 'already running' };
  }
  const tries = force ? 0 : Number(await store.cmd('INCR', K.tries(date)).catch(() => 1)) || 1;
  if (!force && tries === 1) await store.cmd('EXPIRE', K.tries(date), 3 * 86400).catch(() => {});
  if (!force && tries > MAX_TRIES) { await store.cmd('DEL', K.running).catch(() => {}); return { skipped: `gave up after ${MAX_TRIES} failed tries today` }; }

  try {
    const strategy = currentStrategy();
    const on = new Set(((await store.cmd('SMEMBERS', K.users)) || []).map(String));
    const ids = [HOUSE, ...(await practice.allUsers()).map(String).filter(id => id !== HOUSE && allowed.has(id))];
    const out = { date, strategy: strategy.id, closed: 0, signals: 0, bought: {}, accounts: 0 };

    // 1) Sell yesterday's day trades first — even if today's check fails later.
    //    Every practice account, so nobody is left holding a "day" trade (messages only to users with access).
    for (const id of (await practice.allUsers()).map(String)) {
      const trades = await closeDayTrades(id, now);
      out.closed += trades.length;
      if (trades.length && allowed.has(id)) await send(id, closedMessage(trades)).catch(() => {});
    }

    // 2) Today's picks
    let sig;
    try {
      sig = await computeSignals(strategy);
    } catch (err) {
      const next = force ? 'Send `daytrade run` to try again.' : tries < MAX_TRIES ? 'It will try again in about 10 minutes.' : 'No more automatic tries today — send `daytrade run`.';
      if (admin) await send(admin, `⚠️ *Day-trade check failed* (${date}): ${err.message}\n${next}`).catch(() => {});
      throw err;
    }
    out.signals = sig.buys.length;
    await store.setJSON(K.last, { date, at: new Date().toISOString(), strategy: strategy.id, verdict: strategy.verdict, regimeUp: sig.regimeUp, regimeText: sig.regimeText, eligible: sig.eligible, scanned: sig.scanned, listed: sig.listed, buys: sig.buys.map(b => ({ coin: coinOf(b.symbol), why: b.why })) });

    // 3) Buy for the forward-test account and everyone who switched day trading on
    const once = async (id) => force || (await store.cmd('SET', K.did(date, id), '1', 'NX', 'EX', 3 * 86400).catch(() => 'OK')) === 'OK';
    for (const id of ids.filter(x => x === HOUSE || on.has(x))) {
      if (!(await once(id))) continue;
      try {
        out.accounts++;
        const res = await buyForAccount(id, strategy, sig);
        if (res.bought.length) out.bought[id] = res.bought.map(b => b.coin);
        if (id === HOUSE) continue;
        await send(id, res.bought.length ? boughtMessage(res, strategy) : sig.buys.length ? `📆 *Day trades:* nothing bought today — ${res.skipped.join(' · ')}` : noBuyMessage(sig, strategy)).catch(() => {});
      } catch (err) { console.error('[DayTrade] buy', id, err.message); }
    }

    if (admin && (await once('report'))) await send(admin, adminReport(sig, strategy, out)).catch(() => {});
    if (!force) await store.cmd('SET', K.day(date), '1', 'EX', 3 * 86400);
    return out;
  } finally {
    if (!force) await store.cmd('DEL', K.running).catch(() => {});
  }
}

function adminReport(sig, strategy, out) {
  const who = Object.entries(out.bought);
  return [
    `📆 *Day-trade check — ${out.date}*`,
    `_${strategy.label}${strategy.tested ? '' : ' — ⚠️ NOT TESTED: run `npm run daylab`'}_`,
    `Looked at ${sig.scanned} of ${sig.listed} Binance USDT coins · ${sig.eligible} liquid enough · ${sig.qualified} qualified`,
    sig.regimeOn ? `${sig.regimeUp ? '🟢' : '🔴'} Market filter: ${sig.regimeText}` : '',
    sig.buys.length ? `✅ *Picks:* ${sig.buys.map(b => `*${coinOf(b.symbol)}*${b.why ? ` — ${b.why}` : ''}`).join('; ')}` : `No picks today.`,
    `Closed ${out.closed} day trade(s) from yesterday · ${who.length ? `bought: ${who.map(([k, c]) => `${k === HOUSE ? '🏠 house' : `🎮 ${k}`}: ${c.join(', ')}`).join(' · ')}` : 'nothing bought'}`,
  ].filter(Boolean).join('\n');
}

// ─── Status (for the `daytrade` screen) ──────────────────────────────────────
async function status(chatId) {
  const strategy = currentStrategy();
  const [on, paused, last] = await Promise.all([isOn(chatId), isPaused(), store.getJSON(K.last, null)]);
  const acct = await practice.getAccount(HOUSE, { create: false });
  const houseTrades = acct ? await practice.getTrades(HOUSE) : [];
  const days = acct ? Math.floor((Date.now() - new Date(acct.createdAt).getTime()) / D.DAY_MS) : 0;
  const mine = (await practice.getAccount(chatId, { create: false })) ? (await practice.getPositions(chatId)).filter(p => p.day) : [];
  return {
    strategy, on, paused, last, limits: cfg.LIMITS,
    forward: { startedAt: acct?.createdAt || null, days, trades: houseTrades.length, pnlUsd: r2(houseTrades.reduce((s, t) => s + (t.pnlDollar || 0), 0)), winRatePct: houseTrades.length ? r2(houseTrades.filter(t => t.pnlDollar > 0).length / houseTrades.length * 100) : null },
    open: mine.map(p => ({ coin: coinOf(p.symbol), buyPrice: p.buyPrice, stop: p.stopLossPrice, cost: p.cost })),
  };
}

module.exports = {
  DayTradeError, HOUSE, currentStrategy, liveUniverse, computeSignals, size, runDaily, closeDayTrades,
  setOn, isOn, pause, isPaused, status, noBuyMessage, boughtMessage, closedMessage,
};
