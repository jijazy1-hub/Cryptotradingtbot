/**
 * ─── Day-trade lab: test the one-day strategies on EVERY Binance USDT coin ───
 *
 *   npm run daylab                  # every Binance USDT coin, ~4 years of daily candles
 *   npm run daylab -- --days 1000   # less history
 *   npm run daylab -- --refresh     # re-download (otherwise cached for 24h)
 *
 * Tests 3 day-trade families × 4 settings × with/without the BTC market filter
 * (24 variants). Every trade is bought at a daily open and sold at that day's
 * close (or its stop). Settings are chosen on the older 65% of the history and
 * judged on the newer 35% only. Fees and slippage are charged.
 *
 * Run it from a computer that can reach Binance (the first run downloads a few
 * hundred coins and takes several minutes). Writes data/day-strategy.json —
 * commit it: the practice day trader runs the strategy it picks.
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { fetchKlinesWithSource, binanceGet } = require('./src/lib/market');
const { mapLimit } = require('./src/lib/concurrency');
const { dayResearch } = require('./src/services/dayLab');
const cfg = require('./src/config/daytrade');

const CACHE_DIR = path.join(__dirname, 'data', 'cache');
const arg = (n, d) => { const i = process.argv.indexOf(`--${n}`); return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : d; };
const flag = (n) => process.argv.includes(`--${n}`);

async function allBinanceUsdtSymbols() {
  const r = await binanceGet('/exchangeInfo');
  return (r.data.symbols || [])
    .filter(s => s.quoteAsset === 'USDT' && s.status === 'TRADING' && s.isSpotTradingAllowed !== false && cfg.isTradableBase(s.baseAsset))
    .map(s => s.symbol);
}

async function daily(symbol, days, refresh) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
  const file = path.join(CACHE_DIR, `${symbol}-1d.json`);
  if (!refresh && fs.existsSync(file)) {
    try {
      const c = JSON.parse(fs.readFileSync(file, 'utf8'));
      // Older cache files (from `npm run lab`) have no dollar volume → re-download
      if (Date.now() - c.fetchedAt < 24 * 3_600_000 && c.candles.length >= Math.min(days, c.available || days) && c.candles.at(-1)?.quoteVolume !== undefined) return c.candles.slice(-days);
    } catch { /* re-download */ }
  }
  const { candles, exchange } = await fetchKlinesWithSource(symbol, '1d', days, { closedOnly: true, exchange: 'binance' });
  if (exchange !== 'Binance') throw new Error('needs Binance data');
  fs.writeFileSync(file, JSON.stringify({ fetchedAt: Date.now(), available: candles.length, candles }));
  return candles;
}

const pct = (x) => (x === null || x === undefined ? '—' : `${x >= 0 ? '+' : ''}${x}%`);
const r = (x) => (x === null || x === undefined ? '—' : `${x >= 0 ? '+' : ''}${x}R`);

(async () => {
  const days = Number(arg('days', 1500));
  const syms = await allBinanceUsdtSymbols();
  if (!syms.includes('BTCUSDT')) syms.unshift('BTCUSDT');
  console.log(`\nDay-trade lab — ${syms.length} Binance USDT coins, up to ${days} daily candles each\n`);
  const data = {};
  let done = 0, skipped = 0;
  await mapLimit(syms, 4, async (s) => {
    try { data[s] = await daily(s, days, flag('refresh')); } catch { skipped++; }
    if (++done % 50 === 0) console.log(`  …${done}/${syms.length} coins`);
  });
  console.log(`  ${Object.keys(data).length} coins downloaded${skipped ? `, ${skipped} skipped` : ''}`);

  const out = dayResearch(data);
  console.log(`\nPeriod ${out.period.from} → ${out.period.to}. Settings chosen on data before ${out.period.split}; judged only after it.`);
  console.log(`About ${out.universe.avgEligiblePerDay} coins a day were liquid enough to trade (7-day average volume ≥ $${out.rules.eligibility.minVolumeUsd / 1e6}M, ${out.rules.eligibility.minHistoryDays}+ days listed).`);
  console.log(`Costs: ${out.rules.feePct}% fee + ${out.rules.slippagePct}% slippage per side.\n`);
  console.log('Family                          Chosen settings          Unseen: trades /month  win%    avg     95% range          PF   stops  1%-risk portfolio      verdict');
  for (const f of out.families) {
    if (!f.chosen) { console.log(`${f.name.padEnd(32)}${'—'.padEnd(25)}${f.why}`); continue; }
    const t = f.test;
    console.log(`${f.name.padEnd(32)}${f.chosen.id.padEnd(25)}${String(t.trades).padStart(7)} ${String(t.tradesPerMonth).padStart(6)}  ${String(t.winRatePct ?? '—').padStart(5)}  ${r(t.expectancyR).padStart(7)}  ${JSON.stringify(t.expectancyRange95).padEnd(17)}  ${String(t.profitFactor ?? '—').padStart(4)}  ${String(t.stopRatePct).padStart(4)}%  ${pct(f.portfolioTest.returnPct).padStart(8)} (max DD ${f.portfolioTest.maxDrawdownPct}%)  ${f.verdict}`);
  }
  console.log(`\nBTC buy & hold over the unseen period: ${pct(out.btcBuyHoldTestPct)}`);
  console.log(`Note: ${out.rules.bias}.`);
  if (out.pick) {
    console.log(`\nPICKED (best on the training data): ${out.pick.label}`);
    console.log(`VERDICT: ${out.verdict} — ${out.pick.why}`);
  } else {
    console.log('\nVERDICT: FAIL — no strategy had enough trades');
  }
  console.log(out.verdict === 'PASS'
    ? '\nNext: commit data/day-strategy.json. The practice day trader runs this strategy; watch its forward test for a few weeks.'
    : '\nThe practice day trader will run this pick as a labelled experiment (play money only).');

  const file = path.join(__dirname, cfg.STRATEGY_FILE);
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log(`\nSaved ${cfg.STRATEGY_FILE}\n`);
})().catch(e => { console.error('Day-trade lab failed:', e.message); process.exit(1); });
